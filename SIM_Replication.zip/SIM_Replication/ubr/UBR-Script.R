library(foreign)
library(balancer)
library(lme4)
library(sjstats)
library(ICC)

rm(list = ls())

setwd("/Volumes/C-SHE/Keele/UBR/Match Data")
data <- read.dta("ubr-cos.dta")

pat.cov <- c("age", "comorb", "male", "hisp", "afam", 
             "other", "adm_type1", "adm_type2",
             "p_cat1", "p_cat2", "p_cat3", "p_cat4",
             "ynel1", "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
             "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
             "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
             "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
             "ynel29","ynel30",
             "p_type1","p_type2","p_type3", "p_type4",
             "p_type5","p_type6","p_type7","p_type8","p_type9", "p_type10", 
             "p_type11", "p_type12", "p_type13", "p_type14", "p_type15", "p_type16",
             "p_type17", "p_type18", "p_type19", "p_type20", "p_type21", "p_type22", 
             "p_type23", "p_type24", "p_type25","p_type26","p_type27", "p_type28",
             "p_type29","p_type30","p_type31","p_type32","p_type33", "p_type34", 
             "p_type35", "p_type36", "p_type37", "p_type38", "p_type39", "p_type40",
             "p_type41", "p_type42", "p_type43")
             
surg.cov <- c("agenow", "yearsexp", "surgvol_inpt", "surgvol_complex")

## Hyperparameter Selection

all_covs_form <- paste(paste(pat.cov, collapse = "+"), "+", paste(surg.cov, collapse = "+"))

 # timing
t_fexact <- system.time({ 
	
fit.lmer <- lmer(as.formula(paste("complication ~ ", all_covs_form, "+(1 | researchid)")), data)

})

# time required for computation, in minutes
t_fexact[['elapsed']]/60


fit_icc <- performance::icc(fit.lmer)$ICC_adjusted
fit_var <- summary(fit.lmer)$sigma ^ 2
fit_beta_norm <- sqrt(sum(coef(fit.lmer)$researchid[1,-1]^2))
fit_lambda <- fit_var / fit_beta_norm^2

fit_icc
fit_lambda

             
pat_covs <- scale(data[,pat.cov])
surg_covs <- scale(data[,surg.cov])

bal.wts <- cluster_weights(pat_covs, surg_covs , data$treat,
                        data$researchid, lambda = fit_lambda, icc = fit_icc,
                        lowlim = 0, uplim = 1)
                        
# Process the Weights
data$wts <- pmax(bal.wts$weights, 0)
data$wts[data$treat == 1] <- 1  

## Balance -- Selected Covariates

all.cov = c("age", "comorb", "male", "hisp", "white", "afam", 
             "other", "adm_type1", "adm_type2","adm_type3",
             "p_cat1", "p_cat2", "p_cat3", "p_cat4",
             "agenow", "yearsexp", "surgvol_inpt", "surgvol_complex", 
             "surgvol_essential")
             
data.var <- data %>% group_by(treat) %>% 
   summarize(across(all.cov, ~var(.x))) %>% as.data.frame()

c.var <- as.numeric(data.var[1,])
t.var <- as.numeric(data.var[2,])
c.var <- c.var[-1]
t.var <- t.var[-1]
pooled.sd <- sqrt((t.var + c.var/2))

um.wt <- data %>% group_by(treat) %>% 
   summarize(across(all.cov, ~mean(.x))) %>% as.data.frame()

bal.0 <- data %>% group_by(treat) %>% 
   summarize(across(all.cov, ~ weighted.mean(.x, wts))) %>% as.data.frame()

um.wt.tab <- matrix(NA, length(all.cov), 3)
um.wt.tab[,1] <- unlist(um.wt[1,-1]) 
um.wt.tab[,2] <- unlist(um.wt[2,-1])                        
um.wt.tab[,3] <- (unlist(um.wt[2,-1]) - unlist(um.wt[1,-1]))/pooled.sd

bal.0.tab <- matrix(NA, length(all.cov), 3)
bal.0.tab[,1] <- unlist(bal.0[1,-1]) 
bal.0.tab[,2] <- unlist(bal.0[2,-1])                        
bal.0.tab[,3] <- (unlist(bal.0[2,-1]) - unlist(bal.0[1,-1]))/pooled.sd


### Plots and Tables
n_covs <- length(all.cov)
var_names <- c("Age", "No. Comorbidities", "Male", "Hispanic", 
               "White", "African-American", "Other Racial Cat.", "Emergency Admission", 
               "Urgent Admission", "Elective Admission",
               "Medicare", "Medicaid", "Commercial Insur.", "Self Insurance",
               "Surgeon Age", "Years Experience", "No. of Procedures", 
               "No. of Complex Procedures", "No. of Essential Procedures")	

data.plot <- c(bal.0.tab[,3], um.wt.tab[,3])
data.plot <- as.data.frame(data.plot)
names(data.plot) <- "std.dif"
data.plot$contrast <- c(rep(1, n_covs), rep(2, n_covs))
data.plot$contrast <- factor(data.plot$contrast, levels = c(1,2), labels = c("Weighted", "Unweighted"))
data.plot$covariate <- as.factor(var_names)


	
ggplot(data=data.plot, aes(x=std.dif, y=covariate, shape=factor(contrast)))  + 
          geom_point(size=1.75) + 
          scale_shape_manual(name= "Contrast", values=c(1,15)) + 
          xlab("Standardized Difference") + ylab("Covariates") +
          scale_y_discrete(limits = rev(levels(data.plot$covariate))) +
          geom_vline(xintercept= 0) +
          geom_vline(xintercept= 0.05, linetype = "dashed") +
          geom_vline(xintercept= -0.05, linetype = "dashed") +
          theme_bw()


all.cov <- c("treat","age", "comorb", "male", "hisp", "afam", 
             "other", "adm_type1", "adm_type2",
             "p_cat1", "p_cat2", "p_cat3", "p_cat4",
             "agenow", "yearsexp", "surgvol_inpt", "surgvol_complex", "surgvol_essential",
             "ynel1", "ynel2","ynel3","ynel4", "ynel5","ynel6", "ynel7",
             "ynel8","ynel9", "ynel10","ynel11","ynel12","ynel13","ynel14",
             "ynel15","ynel16","ynel17", "ynel18","ynel19","ynel20","ynel21",
             "ynel22","ynel23","ynel24","ynel25","ynel26", "ynel27","ynel28",
             "ynel29","ynel30",
             "p_type1","p_type2","p_type3", "p_type4",
             "p_type5","p_type6","p_type7","p_type8","p_type9", "p_type10", 
             "p_type11", "p_type12", "p_type13", "p_type14", "p_type15", "p_type16",
             "p_type17", "p_type18", "p_type19", "p_type20", "p_type21", "p_type22", 
             "p_type23", "p_type24", "p_type25","p_type26","p_type27", "p_type28",
             "p_type29","p_type30","p_type31","p_type32","p_type33", "p_type34", 
             "p_type35", "p_type36", "p_type37", "p_type38", "p_type39", "p_type40",
             "p_type41", "p_type42", "p_type43")
             
             
## Outcome Estimates
## Unadjusted
fit0 <- lm(complication ~ treat, data = data)
unadj.out <- conf_int(fit0, vcov = "CR2", cluster = data$researchid, test = "Satterthwaite")[2,]
unadj.out


## Balancing Weights

## Better SEs
# manually computed SEs
fit_0 <- lm(complication ~ age + comorb + male + hisp + afam + other + adm_type1 + adm_type2 + 
    p_cat1 + p_cat2 + p_cat3 + p_cat4 + agenow + yearsexp + surgvol_inpt + 
    surgvol_complex + surgvol_essential + ynel1 + ynel2 + ynel3 + 
    ynel4 + ynel5 + ynel6 + ynel7 + ynel8 + ynel9 + ynel10 + 
    ynel11 + ynel12 + ynel13 + ynel14 + ynel15 + ynel16 + ynel17 + 
    ynel18 + ynel19 + ynel20 + ynel21 + ynel22 + ynel23 + ynel24 + 
    ynel25 + ynel26 + ynel27 + ynel28 + ynel29 + ynel30 + p_type1 + 
    p_type2 + p_type3 + p_type4 + p_type5 + p_type6 + p_type7 + 
    p_type8 + p_type9 + p_type10 + p_type11 + p_type12 + p_type13 + 
    p_type14 + p_type15 + p_type16 + p_type17 + p_type18 + p_type19 + 
    p_type20 + p_type21 + p_type22 + p_type23 + p_type24 + p_type25 + 
    p_type26 + p_type27 + p_type28 + p_type29 + p_type30 + p_type31 + 
    p_type32 + p_type33 + p_type34 + p_type35 + p_type36 + p_type37 + 
    p_type38 + p_type39 + p_type40 + p_type41 + p_type42 + p_type43, 
                         data=data[data$treat == 0,])
                         

fit_1 <- lm(complication ~ age + comorb + male + hisp + afam + other + adm_type1 + adm_type2 + 
    p_cat1 + p_cat2 + p_cat3 + p_cat4 + agenow + yearsexp + surgvol_inpt + 
    surgvol_complex + surgvol_essential + ynel1 + ynel2 + ynel3 + 
    ynel4 + ynel5 + ynel6 + ynel7 + ynel8 + ynel9 + ynel10 + 
    ynel11 + ynel12 + ynel13 + ynel14 + ynel15 + ynel16 + ynel17 + 
    ynel18 + ynel19 + ynel20 + ynel21 + ynel22 + ynel23 + ynel24 + 
    ynel25 + ynel26 + ynel27 + ynel28 + ynel29 + ynel30 + p_type1 + 
    p_type2 + p_type3 + p_type4 + p_type5 + p_type6 + p_type7 + 
    p_type8 + p_type9 + p_type10 + p_type11 + p_type12 + p_type13 + 
    p_type14 + p_type15 + p_type16 + p_type17 + p_type18 + p_type19 + 
    p_type20 + p_type21 + p_type22 + p_type23 + p_type24 + p_type25 + 
    p_type26 + p_type27 + p_type28 + p_type29 + p_type30 + p_type31 + 
    p_type32 + p_type33 + p_type34 + p_type35 + p_type36 + p_type37 + 
    p_type38 + p_type39 + p_type40 + p_type41 + p_type42 + p_type43, 
                         data=data[data$treat == 1,])
                                                                       
m0hat <- predict(fit_0, data)
m1hat <- predict(fit_1, data)
se.out <- compute_cluster_se(data$complication, data$wts, data$treat, data$researchid, m1hat, m0hat)

fit1 <- lm(complication ~ treat, data = data, weights = wts)
wt.out <- conf_int(fit1, vcov = "CR2", cluster = data$researchid, test = "Satterthwaite")[2,]
wt.out 

                      