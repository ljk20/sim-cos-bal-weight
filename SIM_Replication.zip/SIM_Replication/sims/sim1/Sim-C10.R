library(matchMulti)
library(foreign)
library(MASS)
library(dplyr)
library(balancer)
library(clubSandwich)
library(lme4)
library(sjstats)

rm(list=ls())

setwd("~/Dropbox/Group Matches/Analysis/Simulation")
data <- read.dta("myon_merge.dta")

#Covariate Lists
bal.cov <- c('readprof','mathprof','readpre','mathpre',
             'hisp','afam','male',
			 'perfcomp','pr_frl','pr_lep',
             'n_students','pr_t_begin','pr_turnover',
             'pr_t_nonwhite')
                       
all.cov <- c('readpre','mathpre','hisp','afam','male','spec_ed', 
			 'perfcomp','readprof','mathprof','pr_frl','pr_lep',
             'n_students','pr_t_begin','pr_turnover',
             'pr_t_nonwhite','title1','title1_focus',
              'treat', 'readpost_imp', 'schoolid')             
             
school.cov <- c('perfcomp','readprof','mathprof','pr_frl','pr_lep',
                'n_students','pr_t_begin','pr_turnover',
                'pr_t_nonwhite')

student.cov <- c('readpre','mathpre','hisp','afam','male')
                                             
# Trim the Data             
data.split <- data[all.cov]

# Remove Schools With One Student
data.split <- data.split %>% filter( !schoolid %in% c(398, 452,  474, 571, 620))

# Sim parameters
nsim <- 1000
c <- 10
z.thresh <- .25

n <- nrow(data.split)
schl.ids <- unique(data.split$schoolid)
n.cl <- length(unique(data.split$schoolid))
nPerClust = tapply(data.split$treat, data.split$schoolid, length)
nCum  = c(0, cumsum(nPerClust))

sd.Y.ctl <- data.split %>% filter(treat==0) %>% dplyr::select(readpost_imp)  %>% summarize(sd(readpost_imp))
sd.Y.ctl <- sd.Y.ctl[[1]]

pscore <-lm(treat ~ perfcomp + pr_frl + pr_lep +
                       n_students + pr_t_begin + pr_t_nonwhite, 
                       data=data.split)  
data.split$prob <- predict(pscore)
school.data <- data.split %>% group_by(schoolid) %>% summarize(z = mean(prob)) %>% data_frame()
      
# Estimate Covariate Outcome Relationships
out <- lm(readpost_imp ~ readpre + mathpre + hisp + afam + male + readpre:afam + mathpre:afam, data=data.split)
# Basis Function  
X <- as.matrix(data.split[bal.cov])
treat.true <- sd(data.split$readpost_imp)*.3                                                   
 
# Sim Storage
out.unadj <- matrix(NA, nsim, 3)
out.wgt <- matrix(NA, nsim, 3)
out.mx.wgt <- matrix(NA, nsim, 3)
out.opt.mlm <- matrix(NA, nsim, 3)

set.seed(12387474)

# Simulations
  for(i in 1:nsim){ 
  	
# Generate Data  	
  	z.star <- (school.data$z/c) + runif(n.cl, -.5, .5)
    Z.j <- as.numeric(z.star > z.thresh)
    #u <- data.split$u.ij + rnorm(nrow(X), 0, 4)
    y0 <- out$coef[1] + 2.5*data.split$readpre + 2.5*data.split$mathpre + 1.9*data.split$perfcomp + rnorm(n, 0, 12)
    y1 <- y0 + treat.true 

      
# Student Level Data
     data.sim = matrix(0, n, (4+ncol(X)))
	 colnames(data.sim) = c("J", "I", "Z", "Y", bal.cov)
	 cl <- 1	
	  
for(cl in 1:n.cl){
	index.cl = (nCum[cl]+1):nCum[cl + 1] 
	
	## data for cluster "cl"	
	data.sim[index.cl, 1] = cl
	data.sim[index.cl, 2] = 1:nPerClust[cl]
	data.sim[index.cl, 3] = rep(Z.j[cl], nPerClust[cl])
	data.sim[index.cl, 4] = (rep(Z.j[cl], nPerClust[cl]))*(y1[index.cl]) + (1 - (rep(Z.j[cl], nPerClust[cl])))*y0[index.cl]                                        
	data.sim[index.cl, 5:(4+ncol(X))] = X[index.cl,]
	data.sim <- as.data.frame(data.sim)
    }
    
## Matching
   # Define binaries to be used for fine balancing
     data.sim$big_perfcomp <- data.sim$perfcomp > quantile(data.sim$perfcomp,.50)
     data.sim$big_readprof <- data.sim$readprof> quantile(data.sim$readprof,.50)
     data.sim$big_mathprof <- data.sim$mathprof > quantile(data.sim$mathprof,.50) 
     data.sim$big_pr_t_begin <- data.sim$pr_t_begin > quantile(data.sim$pr_t_begin, .40)
     data.sim$big_pr_turnover <- data.sim$pr_turnover > quantile(data.sim$pr_turnover, .42)
     data.sim$big_pr_t_nonwhite <- data.sim$pr_t_nonwhite > quantile(data.sim$pr_t_nonwhite, .78)
     data.sim$big_pr_lep <- data.sim$pr_lep > quantile(data.sim$pr_lep, 0.6)

     
# RC Balance Constraints
l1 <- c('big_perfcomp','big_readprof','big_mathprof')
l2 <- c(l1,'big_pr_lep','big_pr_t_nonwhite')
l3 <- c(l1, l2, "big_pr_t_begin", 'big_pr_turnover')

        
# Run the Match
   match.students <- matchMulti(data.sim, treatment = 'Z', 
                       school.id = 'J', match.students = FALSE, verbose=TRUE, 
                       student.vars = student.cov, tol = 0.1, 
                       school.fb = list(l1, l2, l3))           
                                                
# Estimate Treat Effects
   match.data.opt <- as.data.frame(match.students$matched)
   treat.opt.mlm <- lm(Y ~ Z, data=match.data.opt)


### Weighting

## Hyperparameter Selection
   all_covs_form <- paste(paste(student.cov, collapse = "+"), "+", paste(school.cov, collapse = "+"))
   fit <- lmer(as.formula(paste("Y ~ ", all_covs_form, "+(1 | J)")), data.sim)
   fit_icc <- performance::icc(fit)$ICC_adjusted
   fit_var <- summary(fit)$sigma ^ 2
   fit_beta_norm <- sqrt(sum(coef(fit)$J[1,-1]^2))
   fit_lambda <- fit_var / fit_beta_norm^2

   stu_covs <- scale(data.sim[, student.cov])
   sch_covs <- scale(data.sim[,school.cov])
   bal1 <- cluster_weights(stu_covs, sch_covs, data.sim$Z, data.sim$J,
                           lambda = fit_lambda, icc = fit_icc,
                           lowlim = 0, uplim = 1, verbose=FALSE)
  
## Process Weights
   data.sim$w <- pmax(bal1$weights, 0)
   data.sim$w[data.sim$Z == 1] <- 1
   mlm.wt <- lm(Y ~ Z, data=data.sim, weights = w) 

## Max Weights   
   bal2 <- maxsubset_weights_cluster(stu_covs, sch_covs, data.sim$Z, data.sim$J,
                           lambda = fit_lambda, icc = fit_icc,
                           lowlim = 0, uplim = 1, verbose=FALSE)
   data.sim$max.wts <- bal2$weights
   data.sim$max.wts[data.sim$max.wts < 0] <- 0
   mlm.mx.wt <- lm(Y ~ Z, data=data.sim, weights = max.wts)
                                                   
# Unadj
   mlm.un <- lm(Y ~ Z, data=data.sim) 
                             
# Save Results
    out.opt.mlm[i,1] <- summary(treat.opt.mlm)$coef[2]
    out.opt.mlm[i,2] <- conf_int(treat.opt.mlm, vcov = "CR2", cluster = match.data.opt$J, test = "Satterthwaite")[2,5]
    out.opt.mlm[i,3] <- conf_int(treat.opt.mlm, vcov = "CR2", cluster = match.data.opt$J, test = "Satterthwaite")[2,6]
    
    out.wgt[i,1] <- mlm.wt$coef[2]
    out.wgt[i,2] <- conf_int(mlm.wt, vcov = "CR2", cluster = data.sim$J, test = "Satterthwaite")[2,5]
    out.wgt[i,3] <- conf_int(mlm.wt, vcov = "CR2", cluster = data.sim$J, test = "Satterthwaite")[2,6]
    
    out.mx.wgt[i,1] <- mlm.mx.wt$coef[2]
    out.mx.wgt[i,2] <- conf_int(mlm.mx.wt, vcov = "CR2", cluster = data.sim$J, test = "Satterthwaite")[2,5]
    out.mx.wgt[i,3] <- conf_int(mlm.mx.wt, vcov = "CR2", cluster = data.sim$J, test = "Satterthwaite")[2,6]
        
    out.unadj[i,1] <- mlm.un$coef[2]
    out.unadj[i,2] <- conf_int(mlm.un, vcov = "CR2", cluster = data.sim$J, test = "Satterthwaite")[2,5]
    out.unadj[i,3] <- conf_int(mlm.un, vcov = "CR2", cluster = data.sim$J, test = "Satterthwaite")[2,6]

   cat("Simulation: ", i, "\n") 
   }
   
   
setwd("~/Dropbox/Group Matches/Analysis/Simulation/Bal Weights")
save(out.unadj, out.mx.wgt, out.opt.mlm, out.wgt, sd.Y.ctl, treat.true, file ="Sim-C10.RData")	



