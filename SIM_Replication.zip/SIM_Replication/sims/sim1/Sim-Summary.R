## Move to Other Script


library(tidyverse)
library(gridExtra)

rm(list=ls())

setwd("./sims/sim1")
load("Sim-C1.RData")
   
o1 <- apply(out.unadj, 2, mean, na.rm=TRUE)   	
o2 <- apply(out.opt.mlm, 2, mean, na.rm=TRUE)
o5 <- apply(out.wgt, 2, mean, na.rm=TRUE)
o6 <- apply(out.mx.wgt, 2, mean, na.rm=TRUE)

# Bias
bias.unadj.c1 <- (treat.true - o1[1])/sd.Y.ctl
bias.mtchl.c1 <- (treat.true - o2[1])/sd.Y.ctl
bias.wgt.c1 <- (treat.true - o5[1])/sd.Y.ctl
bias.mx.wgt.c1 <- (treat.true - o6[1])/sd.Y.ctl

## MSE
rmse.unadj.c1 <- sqrt(mean((out.unadj[,1] - treat.true)^2)) 	
rmse.mtch.c1  <- sqrt(mean((out.opt.mlm[,1] - treat.true)^2)) 
rmse.wgt.c1 <-sqrt(mean((out.wgt[,1] - treat.true)^2))
rmse.mx.wgt.c1 <-sqrt(mean((out.mx.wgt[,1] - treat.true)^2))

## CVG
cvg.unadj.c1 <- mean(as.numeric((out.unadj[,2] < treat.true) & (treat.true < out.unadj[,3])))
cvg.mtch.c1 <- mean(as.numeric((out.opt.mlm[,2] < treat.true) & (treat.true < out.opt.mlm[,3])))
cvg.wgt.c1 <- mean(as.numeric((out.wgt[,2] < treat.true) & (treat.true < out.wgt[,3])))
cvg.mx.wgt.c1 <- mean(as.numeric((out.mx.wgt[,2] < treat.true) & (treat.true < out.mx.wgt[,3])))

c1.bias <- c(bias.unadj.c1, bias.mtchl.c1, bias.wgt.c1, bias.mx.wgt.c1)
c1.rmse <- c(rmse.unadj.c1, rmse.mtch.c1, rmse.wgt.c1, rmse.mx.wgt.c1)
c1.cvg <- c(cvg.unadj.c1, cvg.mtch.c1, cvg.wgt.c1, cvg.mx.wgt.c1)


rm(out.unadj, out.opt.mlm, out.wgt, out.mx.wgt)

load("Sim-C2.5.RData")

o1 <- apply(out.unadj, 2, mean, na.rm=TRUE)   	
o2 <- apply(out.opt.mlm, 2, mean, na.rm=TRUE)
o5 <- apply(out.wgt, 2, mean, na.rm=TRUE)
o6 <- apply(out.mx.wgt, 2, mean, na.rm=TRUE)

# Bias
bias.unadj.c2.5 <- (treat.true - o1[1])/sd.Y.ctl
bias.mtchl.c2.5 <- (treat.true - o2[1])/sd.Y.ctl
bias.wgt.c2.5 <- (treat.true - o5[1])/sd.Y.ctl
bias.mx.wgt.c2.5 <- (treat.true - o6[1])/sd.Y.ctl

## MSE
rmse.unadj.c2.5 <- sqrt(mean((out.unadj[,1] - treat.true)^2)) 	
rmse.mtch.c2.5  <- sqrt(mean((out.opt.mlm[,1] - treat.true)^2)) 
rmse.wgt.c2.5 <-sqrt(mean((out.wgt[,1] - treat.true)^2))
rmse.mx.wgt.c2.5 <-sqrt(mean((out.mx.wgt[,1] - treat.true)^2))

## CVG
cvg.unadj.c2.5 <- mean(as.numeric((out.unadj[,2] < treat.true) & (treat.true < out.unadj[,3])))
cvg.mtch.c2.5 <- mean(as.numeric((out.opt.mlm[,2] < treat.true) & (treat.true < out.opt.mlm[,3])))
cvg.wgt.c2.5 <- mean(as.numeric((out.wgt[,2] < treat.true) & (treat.true < out.wgt[,3])))
cvg.mx.wgt.c2.5 <- mean(as.numeric((out.mx.wgt[,2] < treat.true) & (treat.true < out.mx.wgt[,3])))

c2.5.bias <- c(bias.unadj.c2.5, bias.mtchl.c2.5, bias.wgt.c2.5, bias.mx.wgt.c2.5)
c2.5.rmse <- c(rmse.unadj.c2.5, rmse.mtch.c2.5, rmse.wgt.c2.5, rmse.mx.wgt.c2.5)
c2.5.cvg <- c(cvg.unadj.c2.5, cvg.mtch.c2.5, cvg.wgt.c2.5, cvg.mx.wgt.c2.5)

rm(out.unadj, out.opt.mlm, out.wgt)

load("Sim-C7.5.RData")

o1 <- apply(out.unadj, 2, mean, na.rm=TRUE)   	
o2 <- apply(out.opt.mlm, 2, mean, na.rm=TRUE)
o5 <- apply(out.wgt, 2, mean, na.rm=TRUE)
o6 <- apply(out.mx.wgt, 2, mean, na.rm=TRUE)

# Bias
bias.unadj.c7.5 <- (treat.true - o1[1])/sd.Y.ctl
bias.mtchl.c7.5 <- (treat.true - o2[1])/sd.Y.ctl
bias.wgt.c7.5 <- (treat.true - o5[1])/sd.Y.ctl
bias.mx.wgt.c7.5 <- (treat.true - o6[1])/sd.Y.ctl

## MSE
rmse.unadj.c7.5 <- sqrt(mean((out.unadj[,1] - treat.true)^2)) 	
rmse.mtch.c7.5  <- sqrt(mean((out.opt.mlm[,1] - treat.true)^2)) 
rmse.wgt.c7.5 <-sqrt(mean((out.wgt[,1] - treat.true)^2))
rmse.mx.wgt.c7.5 <-sqrt(mean((out.mx.wgt[,1] - treat.true)^2))

## CVG
cvg.unadj.c7.5 <- mean(as.numeric((out.unadj[,2] < treat.true) & (treat.true < out.unadj[,3])))
cvg.mtch.c7.5 <- mean(as.numeric((out.opt.mlm[,2] < treat.true) & (treat.true < out.opt.mlm[,3])))
cvg.wgt.c7.5 <- mean(as.numeric((out.wgt[,2] < treat.true) & (treat.true < out.wgt[,3])))
cvg.mx.wgt.c7.5 <- mean(as.numeric((out.mx.wgt[,2] < treat.true) & (treat.true < out.mx.wgt[,3])))

c7.5.bias <- c(bias.unadj.c7.5, bias.mtchl.c7.5, bias.wgt.c7.5, bias.mx.wgt.c7.5)
c7.5.rmse <- c(rmse.unadj.c7.5, rmse.mtch.c7.5, rmse.wgt.c7.5, rmse.mx.wgt.c7.5)
c7.5.cvg <- c(cvg.unadj.c7.5, cvg.mtch.c7.5, cvg.wgt.c7.5, cvg.mx.wgt.c7.5)

rm(out.unadj, out.opt.mlm, out.wgt)

load("Sim-C10.RData")

o1 <- apply(out.unadj, 2, mean, na.rm=TRUE)   	
o2 <- apply(out.opt.mlm, 2, mean, na.rm=TRUE)
o5 <- apply(out.wgt, 2, mean, na.rm=TRUE)
o6 <- apply(out.mx.wgt, 2, mean, na.rm=TRUE)

# Bias
bias.unadj.c10 <- (treat.true - o1[1])/sd.Y.ctl
bias.mtchl.c10 <- (treat.true - o2[1])/sd.Y.ctl
bias.wgt.c10 <- (treat.true - o5[1])/sd.Y.ctl
bias.mx.wgt.c10 <- (treat.true - o6[1])/sd.Y.ctl

## MSE
rmse.unadj.c10 <- sqrt(mean((out.unadj[,1] - treat.true)^2)) 	
rmse.mtch.c10  <- sqrt(mean((out.opt.mlm[,1] - treat.true)^2)) 
rmse.wgt.c10 <-sqrt(mean((out.wgt[,1] - treat.true)^2))
rmse.mx.wgt.c10 <-sqrt(mean((out.mx.wgt[,1] - treat.true)^2))

## CVG
cvg.unadj.c10 <- mean(as.numeric((out.unadj[,2] < treat.true) & (treat.true < out.unadj[,3])))
cvg.mtch.c10 <- mean(as.numeric((out.opt.mlm[,2] < treat.true) & (treat.true < out.opt.mlm[,3])))
cvg.wgt.c10 <- mean(as.numeric((out.wgt[,2] < treat.true) & (treat.true < out.wgt[,3])))
cvg.mx.wgt.c10 <- mean(as.numeric((out.mx.wgt[,2] < treat.true) & (treat.true < out.mx.wgt[,3])))

c10.bias <- c(bias.unadj.c10, bias.mtchl.c10, bias.wgt.c10, bias.mx.wgt.c10)
c10.rmse <- c(rmse.unadj.c10, rmse.mtch.c10, rmse.wgt.c10, rmse.mx.wgt.c10)
c10.cvg <- c(cvg.unadj.c10, cvg.mtch.c10, cvg.wgt.c10, cvg.mx.wgt.c10 )



sim.dat <- tibble(bias = c(c1.bias, c2.5.bias, c7.5.bias, c10.bias),
                 rmse = c(c1.rmse, c2.5.rmse, c7.5.rmse, c10.rmse),
                 cvg = c(c1.cvg, c2.5.cvg, c7.5.cvg, c10.cvg),
                 c.idx = c(rep(1, 4), rep(2,4), rep(3,4), rep(4,4)),
                 method = rep(seq(1,4,1), 4))


sim.dat$method <- factor(sim.dat$method, levels =  c(1,2,3,4), labels = c("Unadjusted", "ML Matching", "Weighting","Subset Weighting"))
sim.dat$c.idx <- factor(sim.dat$c.idx, levels =  c(1,2,3,4), labels = c("Poor Overlap", "Low", "Medium", "Good Overlap"))


sim.se <- 2*sqrt(.95*(1-.95)/1000)

p1 <- ggplot(sim.dat, aes(x=c.idx, y=bias, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Degree of Overlap") + 
  #ylab("Percentage Points of Outcome") +
  ylab( "Standardized Bias" ) +
  theme_bw() +
  theme(legend.position="none")
  geom_hline(yintercept = 0) +
  geom_hline(yintercept= sim.se, linetype="dashed") +
  geom_hline(yintercept= -sim.se, linetype="dashed")
 
  
p2 <-  ggplot(sim.dat, aes(x=c.idx, y=rmse, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Degree of Overlap") + 
  #ylab("Percentage Points of Outcome") +
  ylab( "RMSE" ) +
  theme_bw() +
  theme(legend.title=element_blank())  

setwd("~/Dropbox/Group Matches/Drafts/Bal Weights/figures")
pdf("sim-main.pdf", width=10, height=4, onefile=FALSE, paper="special")
grid.arrange(p1, p2, nrow=1, widths = c(1,1.2))
dev.off() 


  


