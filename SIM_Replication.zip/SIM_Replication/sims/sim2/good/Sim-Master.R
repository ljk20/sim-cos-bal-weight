rm(list=ls())

setwd("./sims/sim2/good")
source("SE-Sim-C50.R")
setwd("./sims/sim2/good")
source("SE-Sim-C100.R")
setwd("./sims/sim2/good")
source("SE-Sim-C150.R")
setwd("./sims/sim2/good")
source("SE-Sim-C200.R")
setwd("./sims/sim2/good")
source("SE-Sim-C250.R")



