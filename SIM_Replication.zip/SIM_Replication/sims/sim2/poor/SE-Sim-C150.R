
library(foreign)
library(MASS)
library(dplyr)
library(balancer)
library(clubSandwich)
library(lme4)
library(sjstats)

rm(list=ls())

setwd("~/Dropbox/Group Matches/Analysis/Simulation")
data <- read.dta("myon_merge.dta")

#Covariate Lists
bal.cov <- c('readprof','mathprof','readpre','mathpre',
             'hisp','afam','male',
			 'perfcomp','pr_frl','pr_lep',
             'n_students','pr_t_begin','pr_turnover',
             'pr_t_nonwhite')
                       
all.cov <- c('readpre','mathpre','hisp','afam','male','spec_ed', 
			 'perfcomp','readprof','mathprof','pr_frl','pr_lep',
             'n_students','pr_t_begin','pr_turnover',
             'pr_t_nonwhite','title1','title1_focus',
              'treat', 'readpost_imp', 'schoolid')             
             
school.cov <- c('perfcomp','readprof','mathprof','pr_frl','pr_lep',
                'n_students','pr_t_begin','pr_turnover',
                'pr_t_nonwhite')

student.cov <- c('readpre','mathpre','hisp','afam','male')
                                             
# Trim the Data             
data.split <- data[all.cov]

# Remove Schools With One Student
data.split <- data.split %>% filter( !schoolid %in% c(398, 452,  474, 571, 620))

## Hyperparameter Selection
   all_covs_form <- paste(paste(student.cov, collapse = "+"), "+", paste(school.cov, collapse = "+"))
   fit <- lmer(as.formula(paste("readpost_imp ~ ", all_covs_form, "+(1 | schoolid)")), data.split)
   fit_icc <- performance::icc(fit)$ICC_adjusted
   fit_var <- summary(fit)$sigma ^ 2
   fit_beta_norm <- sqrt(sum(coef(fit)$schoolid[1,-1]^2))
   fit_lambda <- fit_var / fit_beta_norm^2

# Sim parameters
nsim <- 1000
c <- 1
z.thresh <- .25
n.cl <- 150

schl.ids <- unique(data.split$schoolid)
length(schl.ids)

clusters <- names(table(data.split$schoolid))
index <- sample(1:length(clusters), n.cl, replace=TRUE)
aa <- clusters[index]

newdat <- NULL
for(i in 1:length(aa)){
	cc <- data.split[data.split$schoolid %in% aa[i],]
	cc$schoolid <- cc$schoolid + round(runif(1, .1), 6)
	newdat <- rbind(newdat, cc)
}

length(unique(newdat$schoolid))
n <- nrow(newdat)

nPerClust = tapply(newdat$treat, newdat$schoolid, length)
nCum  = c(0, cumsum(nPerClust))

sd.Y.ctl <- data.split %>% filter(treat==0) %>% dplyr::select(readpost_imp)  %>% summarize(sd(readpost_imp))
sd.Y.ctl <- sd.Y.ctl[[1]]

# Estimate Covariate Outcome Relationships
out <- lm(readpost_imp ~ readpre + mathpre + hisp + afam + male + readpre:afam + mathpre:afam, data=data.split)

pscore <-lm(treat ~ perfcomp + pr_frl + pr_lep +
                       n_students + pr_t_begin + pr_t_nonwhite, 
                       data=newdat)  
newdat$prob <- predict(pscore)
school.data <- newdat %>% group_by(schoolid) %>% summarize(z = mean(prob)) %>% data_frame()
      
# Basis Function  
X <- as.matrix(newdat[bal.cov])
treat.true <- sd(data.split$readpost_imp)*.3                                                   

 
# Sim Storage
out.wgt.1 <- matrix(NA, nsim, 4)
out.wgt.2 <- matrix(NA, nsim, 4)

set.seed(12387474)

# Simulations
  for(i in 1:nsim){ 
  	
# Generate Data
  	z.star <- (school.data$z/c) + runif(n.cl, -.5, .5)
    Z.j <- as.numeric(z.star > z.thresh)
    y0 <- out$coef[1] + .77*newdat$readpre -.19*newdat$mathpre + .08*newdat$perfcomp + rnorm(n, 0, 38)
    y1 <- y0 + treat.true 

      
# Student Level Data
     data.sim = matrix(0, n, (4+ncol(X)))
	 colnames(data.sim) = c("J", "I", "Z", "Y", bal.cov)
		  
for(cl in 1:n.cl){
	index.cl = (nCum[cl]+1):nCum[cl + 1] 
	
	## data for cluster "cl"	
	data.sim[index.cl, 1] = cl
	data.sim[index.cl, 2] = 1:nPerClust[cl]
	data.sim[index.cl, 3] = rep(Z.j[cl], nPerClust[cl])
	data.sim[index.cl, 4] = (rep(Z.j[cl], nPerClust[cl]))*(y1[index.cl]) + (1 - (rep(Z.j[cl], nPerClust[cl])))*y0[index.cl]                                        
	data.sim[index.cl, 5:(4+ncol(X))] = X[index.cl,]
	data.sim <- as.data.frame(data.sim)
    }
    

### Weighting
   stu_covs <- scale(data.sim[, student.cov])
   sch_covs <- scale(data.sim[, school.cov])
   bal1 <- cluster_weights(stu_covs, sch_covs, data.sim$Z, data.sim$J,
                           lambda = fit_lambda, icc = fit_icc,
                           lowlim = 0, uplim = 1, verbose=FALSE)
  
## Process Weights
   data.sim$w <- pmax(bal1$weights, 0)
   data.sim$w[data.sim$Z == 1] <- 1
   mlm.wt <- lm(Y ~ Z, data=data.sim, weights = w)
   
   fit0 <- lm(Y ~ pr_frl + pr_lep + perfcomp +
                    readprof + mathprof +
                    n_students + pr_t_begin +
                    pr_turnover + pr_t_nonwhite +
                    hisp + afam + male + 
                    readpre + mathpre, 
                  data=data.sim[data.sim$Z == 0,])
  fit1 <- lm(Y ~ pr_frl + pr_lep + perfcomp +
                    readprof + mathprof +
                    n_students + pr_t_begin +
                    pr_turnover + pr_t_nonwhite +
                    hisp + afam + male + 
                    readpre + mathpre, 
                  data=data.sim[data.sim$Z == 1,])
  m0hat <- predict(fit0, data.sim)
  m1hat <- predict(fit1, data.sim)
  se.out <- compute_cluster_se(data.sim$Y, data.sim$w, data.sim$Z, data.sim$J, m1hat, m0hat)

  sand <- conf_int(mlm.wt, vcov = "CR2", cluster = data.sim$J, test = "Satterthwaite")
  crit <- qt(1 - (1- 0.95)/2, df = sand[2,4])

# Save Results    
    out.wgt.1[i,1] <- se.out[3,2]
    out.wgt.1[i,2] <- se.out[3,3]
    out.wgt.1[i,3] <- (se.out[3,2] - se.out[3,3] * crit)
    out.wgt.1[i,4] <- (se.out[3,2] + se.out[3,3] * crit)
    
    out.wgt.2[i,1] <- mlm.wt$coef[2]
    out.wgt.2[i,2] <- sand[2,3]
    out.wgt.2[i,3] <- sand[2,5]
    out.wgt.2[i,4] <- sand[2,6]
            
   cat("Simulation: ", i, "\n") 
   }
   
   
o1 <- apply(out.wgt.1, 2, mean, na.rm=TRUE)   	
o2 <- apply(out.wgt.2, 2, mean, na.rm=TRUE)
   
setwd("~/Dropbox/Group Matches/Analysis/Simulation/Bal Weights/SE Sim/poor")
save(out.wgt.1, out.wgt.2, sd.Y.ctl, treat.true, file ="Sim-C150.RData")	



