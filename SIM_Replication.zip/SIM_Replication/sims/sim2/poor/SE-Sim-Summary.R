## Move to Other Script

library(tidyverse)
library(gridExtra)

rm(list=ls())

setwd("./sims/sim2/poor")
load("Sim-C50.RData")
   
o1 <- apply(out.wgt.1, 2, mean, na.rm=TRUE)   	
o2 <- apply(out.wgt.2, 2, mean, na.rm=TRUE)

se.wgt1.c1 <- o1[2]/sqrt(var( out.wgt.1[,1] ))
se.wgt2.c1 <- o2[2]/sqrt(var( out.wgt.2[,1] ))

## CVG
cvg.wgt1.c1 <- mean(as.numeric((out.wgt.1[,3] < treat.true) & (treat.true < out.wgt.1[,4])))
cvg.wgt2.c1 <- mean(as.numeric((out.wgt.2[,3] < treat.true) & (treat.true < out.wgt.2[,4])))

wgt1.leng.c1 <- mean(abs( out.wgt.1[,4] - out.wgt.1[,3] ))
wgt2.leng.c1 <- mean(abs( out.wgt.2[,4] - out.wgt.2[,3] ))

c1.se <- c(se.wgt1.c1, se.wgt2.c1)
c1.cvg <- c(cvg.wgt1.c1, cvg.wgt2.c1)
c1.ci <- c(wgt1.leng.c1, wgt2.leng.c1)

rm(out.wgt.1, out.wgt.2)

load("Sim-C100.RData")

o1 <- apply(out.wgt.1, 2, mean, na.rm=TRUE)   	
o2 <- apply(out.wgt.2, 2, mean, na.rm=TRUE)

se.wgt1.c2 <- o1[2]/sqrt(var( out.wgt.1[,1] ))
se.wgt2.c2 <- o2[2]/sqrt(var( out.wgt.2[,1] ))

## CVG
cvg.wgt1.c2 <- mean(as.numeric((out.wgt.1[,3] < treat.true) & (treat.true < out.wgt.1[,4])))
cvg.wgt2.c2 <- mean(as.numeric((out.wgt.2[,3] < treat.true) & (treat.true < out.wgt.2[,4])))

wgt1.leng.c2 <- mean(abs( out.wgt.1[,4] - out.wgt.1[,3] ))
wgt2.leng.c2 <- mean(abs( out.wgt.2[,4] - out.wgt.2[,3] ))

c2.se <- c(se.wgt1.c2, se.wgt2.c2)
c2.cvg <- c(cvg.wgt1.c2, cvg.wgt2.c2)
c2.ci <- c(wgt1.leng.c2, wgt2.leng.c2)

rm(o1, o2, out.wgt.1, out.wgt.2)

load("Sim-C150.RData")

o1 <- apply(out.wgt.1, 2, mean, na.rm=TRUE)   	
o2 <- apply(out.wgt.2, 2, mean, na.rm=TRUE)

se.wgt1.c3 <- o1[2]/sqrt(var( out.wgt.1[,1] ))
se.wgt2.c3 <- o2[2]/sqrt(var( out.wgt.2[,1] ))

## CVG
cvg.wgt1.c3 <- mean(as.numeric((out.wgt.1[,3] < treat.true) & (treat.true < out.wgt.1[,4])))
cvg.wgt2.c3 <- mean(as.numeric((out.wgt.2[,3] < treat.true) & (treat.true < out.wgt.2[,4])))

wgt1.leng.c3 <- mean(abs( out.wgt.1[,4] - out.wgt.1[,3] ))
wgt2.leng.c3 <- mean(abs( out.wgt.2[,4] - out.wgt.2[,3] ))

c3.se <- c(se.wgt1.c3, se.wgt2.c3)
c3.cvg <- c(cvg.wgt1.c3, cvg.wgt2.c3)
c3.ci <- c(wgt1.leng.c3, wgt2.leng.c3)

rm(o1, o2, out.wgt.1, out.wgt.2)

load("Sim-C200.RData")

o1 <- apply(out.wgt.1, 2, mean, na.rm=TRUE)   	
o2 <- apply(out.wgt.2, 2, mean, na.rm=TRUE)

se.wgt1.c4 <- o1[2]/sqrt(var( out.wgt.1[,1] ))
se.wgt2.c4 <- o2[2]/sqrt(var( out.wgt.2[,1] ))

## CVG
cvg.wgt1.c4 <- mean(as.numeric((out.wgt.1[,3] < treat.true) & (treat.true < out.wgt.1[,4])))
cvg.wgt2.c4 <- mean(as.numeric((out.wgt.2[,3] < treat.true) & (treat.true < out.wgt.2[,4])))

wgt1.leng.c4 <- mean(abs( out.wgt.1[,4] - out.wgt.1[,3] ))
wgt2.leng.c4 <- mean(abs( out.wgt.2[,4] - out.wgt.2[,3] ))

c4.se <- c(se.wgt1.c4, se.wgt2.c4)
c4.cvg <- c(cvg.wgt1.c4, cvg.wgt2.c4)
c4.ci <- c(wgt1.leng.c4, wgt2.leng.c4)

rm(o1, o2, out.wgt.1, out.wgt.2)

load("Sim-C250.RData")

o1 <- apply(out.wgt.1, 2, mean, na.rm=TRUE)   	
o2 <- apply(out.wgt.2, 2, mean, na.rm=TRUE)

se.wgt1.c5 <- o1[2]/sqrt(var( out.wgt.1[,1] ))
se.wgt2.c5 <- o2[2]/sqrt(var( out.wgt.2[,1] ))

## CVG
cvg.wgt1.c5 <- mean(as.numeric((out.wgt.1[,3] < treat.true) & (treat.true < out.wgt.1[,4])))
cvg.wgt2.c5 <- mean(as.numeric((out.wgt.2[,3] < treat.true) & (treat.true < out.wgt.2[,4])))

wgt1.leng.c5 <- mean(abs( out.wgt.1[,4] - out.wgt.1[,3] ))
wgt2.leng.c5 <- mean(abs( out.wgt.2[,4] - out.wgt.2[,3] ))

c5.se <- c(se.wgt1.c5, se.wgt2.c5)
c5.cvg <- c(cvg.wgt1.c5, cvg.wgt2.c5)
c5.ci <- c(wgt1.leng.c5, wgt2.leng.c5)

rm(o1, o2, out.wgt.1, out.wgt.2)

sim.dat <- tibble(se = c(c1.se, c2.se, c3.se, c4.se, c5.se),
                 cvg = c(c1.cvg, c2.cvg, c3.cvg, c4.cvg, c5.cvg),
                 leng = c(c1.ci, c2.ci, c3.ci, c4.ci, c5.ci),
                  c.idx = c(rep(1, 2), rep(2,2), rep(3,2), rep(4,2), rep(5,2)),
                  method = rep(seq(1,2,1), 5))



sim.dat$method <- factor(sim.dat$method, levels =  c(1,2), labels = c("Plug-in SE", "Sandwich SE"))
sim.dat$c.idx <- factor(sim.dat$c.idx, levels =  c(1,2,3,4,5), labels = c("50", "100", "150", "200", "250"))


p1 <- ggplot(sim.dat, aes(x=c.idx, y=se, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Number of Clusters") + 
  ylab( "Ratio of SE to Empirical SE" ) +
  theme_bw() +
  theme(legend.position="none") 
  

p2 <- ggplot(sim.dat, aes(x=c.idx, y=leng, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Number of Clusters") + 
  ylab( "Confidence Interval Length" ) +
  theme_bw() +
  theme(legend.position="none")  
  
   
p3 <- ggplot(sim.dat, aes(x=c.idx, y=cvg, group=method)) + 
  geom_line(aes(color=method)) + 
  geom_point(aes(shape=method), size=1.5) + 
  xlab("Number of Clusters") + 
  ylab( "Coverage" ) +
  theme_bw() +
  theme(legend.title=element_blank()) +
  ylim(.9, 1.02)

pdf("se-sim-poor.pdf", width=12, height=3, onefile=FALSE, paper="special")
grid.arrange(p1, p2, p3, nrow=1, widths = c(1, 1, 1.2))



