

The code in this replication file allows for a complete replication of the analyses in our manuscript.  

Catholic Schools

Data for this analysis are available online in the R package matchMulti.


UBR Surgeons

We are unable to provide data for this analysis. Data are available from the states of PA, FL, and NY with an appropriate DUA. We include the R script we used for the analysis.

Sims

These folders contain both the scripts to run the simulations and output from the simulations we used in the analysis.


