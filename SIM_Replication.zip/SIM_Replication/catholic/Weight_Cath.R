library(matchMulti)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(balancer)
library(lme4)
library(sjstats)
library(clubSandwich)
 
# Load Data
rm(list=ls())
data(catholic_schools)

catholic_schools$sectorf <- factor(catholic_schools$sector, label=c("Public", "Catholic"))

#Number of Treated Schools
length(table(catholic_schools$school[catholic_schools$sector==1]))

#Number of Controls Schools
length(table(catholic_schools$school[catholic_schools$sector==0]))
nrow(catholic_schools)

# Remove Non-Coed Schools
summary(catholic_schools$female_mean)
summary(catholic_schools$female_mean[catholic_schools$sector==1])
summary(catholic_schools$female_mean[catholic_schools$sector==0])
catholic_schools <- catholic_schools %>% filter(female_mean>.30, female_mean<.75)
summary(catholic_schools$female_mean)

# Covariate Lists
student.cov <- c('minority', 'female','ses')
school.cov <- c('minority_mean', 'female_mean', 'size', 'acad', 'discrm', 'ses_mean')
all.cov <- c('minority','female','ses','minority_mean', 'female_mean', 'size', 'acad', 'discrm', 'ses_mean')

# Balance After Trimming 
bal_trimmed <- balanceTable(catholic_schools[c(all.cov,'sector')],  treatment = 'sector')
bal_trimmed

## Hyperparameter Selection
all_covs_form <- paste(paste(student.cov, collapse = "+"), "+", paste(school.cov, collapse = "+"))
fit <- lmer(as.formula(paste("mathach ~ ", all_covs_form, "+(1 | school)")), catholic_schools)
fit_icc <- performance::icc(fit)$ICC_adjusted
fit_var <- summary(fit)$sigma ^ 2
fit_beta_norm <- sqrt(sum(coef(fit)$school[1,-1]^2))
fit_lambda <- fit_var / fit_beta_norm^2

fit_icc
fit_lambda

stu_covs <- scale(catholic_schools[,student.cov])
sch_covs <- scale(catholic_schools[,school.cov])

bal.lambda.100 <- cluster_weights(stu_covs,
                        sch_covs, catholic_schools$sector,
                        catholic_schools$school, lambda = fit_lambda, icc = fit_icc,
                        lowlim = 0, uplim = 1)

bal.maxsubset <-  maxsubset_weights_cluster(stu_covs,
                        sch_covs, catholic_schools$sector,
                        catholic_schools$school, lambda = fit_lambda, icc = fit_icc,
                        lowlim = 0, uplim = 1)

data <- catholic_schools

# Process the Weights
data$wts <- pmax(bal.lambda.100$weights, 0)
data$wts[data$sector == 1] <- 1
data$max.wts <- bal.maxsubset$weights


## Balance
all.cov <- c('ses','minority_mean', 'female_mean', 'size', 'acad', 'discrm', 'ses_mean')
             
data.var <- data %>% group_by(sector) %>% 
   summarize(across(all.cov, ~var(.x))) %>% as.data.frame()

c.var <- as.numeric(data.var[1,])
t.var <- as.numeric(data.var[2,])
c.var <- c.var[-1]
t.var <- t.var[-1]
pooled.sd <- sqrt((t.var + c.var/2))

um.wt <- data %>% group_by(sector) %>% 
   summarize(across(all.cov, ~mean(.x))) %>% as.data.frame()

bal.0 <- data %>% group_by(sector) %>% 
   summarize(across(all.cov, ~ weighted.mean(.x, wts))) %>% as.data.frame()

bal.0.tr <- data %>% group_by(sector) %>% 
   summarize(across(all.cov, ~ weighted.mean(.x, wts.tr))) %>% as.data.frame()
   
bal.max <- data %>% group_by(sector) %>% 
   summarize(across(all.cov, ~ weighted.mean(.x, max.wts))) %>% as.data.frame()   

um.wt.tab <- matrix(NA, length(all.cov), 3)
um.wt.tab[,1] <- unlist(um.wt[1,-1]) 
um.wt.tab[,2] <- unlist(um.wt[2,-1])                        
um.wt.tab[,3] <- (unlist(um.wt[2,-1]) - unlist(um.wt[1,-1]))/pooled.sd

bal.0.tab <- matrix(NA, length(all.cov), 3)
bal.0.tab[,1] <- unlist(bal.0[1,-1]) 
bal.0.tab[,2] <- unlist(bal.0[2,-1])                        
bal.0.tab[,3] <- (unlist(bal.0[2,-1]) - unlist(bal.0[1,-1]))/pooled.sd
         
bal.max.tab <- matrix(NA, length(all.cov), 3)
bal.max.tab[,1] <- unlist(bal.max[1,-1]) 
bal.max.tab[,2] <- unlist(bal.max[2,-1])                        
bal.max.tab[,3] <- (unlist(bal.max[2,-1]) - unlist(bal.max[1,-1]))/pooled.sd


## Comparisons To Matching
load("cschools_matchout.RData")

match.data3 <- as.data.frame(match_3$matched)
length(unique(match.data3$school[match.data3$sector==1]))

bal.m <- match.data3 %>% group_by(sector) %>% 
   summarize(across(all.cov, ~mean(.x))) %>% as.data.frame()

m.tab <- matrix(NA, length(all.cov), 3)
m.tab[,1] <- unlist(bal.m[1,-1]) 
m.tab[,2] <- unlist(bal.m[2,-1])                        
m.tab[,3] <- (unlist(bal.m[2,-1]) - unlist(bal.m[1,-1]))/pooled.sd

match.data4 <- as.data.frame(match_4$matched)
length(unique(match.data4$school[match.data4$sector==1]))

bal.m.tr <- match.data4 %>% group_by(sector) %>% 
   summarize(across(all.cov, ~mean(.x))) %>% as.data.frame()

m.tab.tr <- matrix(NA, length(all.cov), 3)
m.tab.tr[,1] <- unlist(bal.m.tr[1,-1]) 
m.tab.tr[,2] <- unlist(bal.m.tr[2,-1])                        
m.tab.tr[,3] <- (unlist(bal.m.tr[2,-1]) - unlist(bal.m.tr[1,-1]))/pooled.sd

var_names <- c("Student SES", "% Students Minority", "% Students Female",
			"Enrollment", "% Students on Academic Track", "Disciplinary Climate Scale", "School SES Average")

bal.tab <- cbind(round(um.wt.tab[,3],2), round(bal.0.tab[,3], 2), round(bal.max.tab[,3],2), round(m.tab[,3], 2), round(m.tab.tr[,3], 2))
rownames(bal.tab) <- var_names
colnames(bal.tab) <- c("Unweighted", "Weights", "Max Subset Wts", "Matching", "Matching - Trimmed")
bal.tab

library(xtable)
xtable(bal.tab)

## Estimand Comparisons
n_covs <- length(all.cov)
data.plot.c <- c(um.wt.tab[,2], bal.max.tab[,2],um.wt.tab[,1], bal.max.tab[,1])
data.plot.c <- as.data.frame(data.plot.c)
names(data.plot.c) <- "mean"
data.plot.c$contrast <- c(rep(1, n_covs), rep(2, n_covs), rep(3, n_covs), rep(4, n_covs))
data.plot.c$contrast <- factor(data.plot.c$contrast, levels = c(1,2,3,4), labels = 
c("Unweighted - Catholic", "Subset Wgt. - Catholic", "Unweighted - Public", "Subset Wgt. - Public"))
data.plot.c$covariate <- as.factor(var_names)
data.plot.c <- data.plot.c %>% filter(covariate!="Enrollment")

ggplot(data=data.plot.c, aes(x=mean, y=covariate, shape=factor(contrast)))  + 
          geom_point(size=2.25) +
          xlab("Means") + ylab("Covariates") +
          theme_bw() + theme(axis.text = element_text(size = 13)) + 
           guides(shape=guide_legend(title="Contrast"))

data$std_math_score <- (data$mathach - mean(data$mathach, na.rm = TRUE))/
  sd(data$mathach [data$sector == 0], na.rm = TRUE)

## Outcome Estimates
data$std_math_score <- (data$mathach - mean(data$mathach, na.rm = TRUE))/
  sd(data$mathach [data$sector == 0], na.rm = TRUE)
  
## Unadjusted
fit0 <- lm(std_math_score ~ sector, data = data)
unadj.out <- conf_int(fit0, vcov = "CR2", cluster = data$school, test = "z")[2,]
unadj.out

## Multilevel Matched
match.data3 <- as.data.frame(match_3$matched)
match.data3$std_math_score <- (match.data3$mathach - mean(match.data3$mathach, na.rm = TRUE))/
  sd(match.data3$mathach [match.data3$sector == 0], na.rm = TRUE)

fit2 <- lm(std_math_score ~ sector, data=match.data3)
mtch3 <- conf_int(fit2, vcov = "CR2", cluster = match.data3$school, test = "z")[2,]
mtch3

## Matching with Trimming
match.data4 <- as.data.frame(match_4$matched)
match.data4$std_math_score <- (match.data4$mathach - mean(match.data4$mathach, na.rm = TRUE))/
  sd(match.data4$mathach [match.data4$sector == 0], na.rm = TRUE)

fit4 <- lm(std_math_score ~ sector, data=match.data4)
mtch4 <- conf_int(fit4, vcov = "CR2", cluster = match.data4$school, test = "z")[2,]
mtch4


#### Balancing Weights
fit6 <- lm(std_math_score ~ sector, data = data, weights = wts)
wgt <- conf_int(fit6, vcov = "CR2", cluster = data$school, test = "z")
wgt

# manually computed SEs
fit0 <- lm(std_math_score ~ minority_mean + female_mean + 
                            size + acad + discrm + 
                            ses_mean + size + female + minority, 
                            data=data[data$sector == 0,])
fit1 <- lm(std_math_score ~ minority_mean + female_mean + 
                            size + acad + discrm + 
                            ses_mean + size + female + minority, 
                            data=data[data$sector == 1,])
  m0hat <- predict(fit0, data)
  m1hat <- predict(fit1, data)
  se.out <- compute_cluster_se(data$std_math_score, data$wts, data$sector, data$school, m1hat, m0hat)
  crit <- qt(1 - (1 - .95)/2, df = Inf)

se.out[3,2]
se.out[3,2] - crit*se.out[3,3]
se.out[3,2] + crit*se.out[3,3]


## Max Subset Weights
fit8 <- lm(std_math_score ~ sector, data = data, weights = max.wts)
mx.wgt <- conf_int(fit8, vcov = "CR2", cluster = data$school, test = "z")[2,]
mx.wgt

se.out.mx <- compute_cluster_se(data$std_math_score, data$max.wts, data$sector, data$school, m1hat, m0hat)

se.out.mx[3,2]
se.out.mx[3,2] - crit*se.out.mx[3,3]
se.out.mx[3,2] + crit*se.out.mx[3,3]
